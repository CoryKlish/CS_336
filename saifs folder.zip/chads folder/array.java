package com.example.compsci.myapplication;

import java.util.ArrayList;

public class array {
    static ArrayList<String> cal= new ArrayList<>();
    static ArrayList<String> sug= new ArrayList<>();
    static ArrayList<String> fib= new ArrayList<>();
    static ArrayList<String> fat= new ArrayList<>();
    static ArrayList<String> car= new ArrayList<>();
    static ArrayList<String> pro= new ArrayList<>();
    public static ArrayList<String> getCalories() {
        return cal;
    }
    public static ArrayList<String> getSugar() {
        return sug;
    }
    public static ArrayList<String> getFiber() {
        return fib;
    }
    public static ArrayList<String> getFat() {
        return fat;
    }
    public static ArrayList<String> getCarbs() {
        return car;
    }
    public static ArrayList<String> getProtein() {
        return pro;
    }
}
